﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TestWebAPICSharp.Models
{
    public class WaterStation
    {
        public string description { get; set; }
        public string County { get; set; }
    }
}